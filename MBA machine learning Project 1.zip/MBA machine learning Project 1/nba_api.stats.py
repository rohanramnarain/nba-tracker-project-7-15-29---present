import pandas as pd
from nba_api.stats.endpoints import leaguegamefinder

# Get recent games
games = leaguegamefinder.LeagueGameFinder(season_nullable='2024-25')
df = games.get_data_frames()[0]
print(f"Found {len(df)} games")

# Save ALL games to CSV with a different name
df.to_csv('nba_games_full.csv', index=False)
print(f"Saved all {len(df)} games to nba_games_full.csv")

# Show first few rows in terminal
print(df.head())