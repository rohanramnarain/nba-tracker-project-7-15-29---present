import pandas as pd
from nba_api.stats.endpoints import leaguegamefinder

# Set pandas display options
pd.set_option('display.max_rows', 100)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', 100)

# Get recent games
games = leaguegamefinder.LeagueGameFinder(season_nullable='2024-25')
df = games.get_data_frames()[0]
print(f"Found {len(df)} games")

# Save ALL 5128 games to CSV
df.to_csv('nba_games_sample.csv', index=False)
print(f"Saved all {len(df)} games to nba_games_sample.csv")

# Show first few rows in terminal
print(df.head())