import pandas as pd
from nba_api.stats.endpoints import teamgamelog, scoreboardv2, playbyplayv2
from nba_api.stats.static import teams
from datetime import datetime
import os

# ========== SET TARGET GAME DATE ========== #
# Format: "MM-DD-YYYY" or "YYYY-MM-DD" works
game_date = "2025-06-22"  # Example date with summer league games

# ========== PART 1: Game Start Times (Tip-off) ========== #
scoreboard = scoreboardv2.ScoreboardV2(game_date=game_date)
games_header = scoreboard.get_data_frames()[0]

print("=== Game Start Times ===")
print(games_header[['GAME_ID', 'GAME_DATE_EST', 'GAME_STATUS_TEXT', 'HOME_TEAM_ID', 'VISITOR_TEAM_ID', 'LIVE_PERIOD', 'LIVE_PC_TIME', 'GAME_SEQUENCE']])
print()

# ========== PART 2: Team Game Logs ========== #
team_list = teams.get_teams()
team_id = team_list[0]['id']  # First team (e.g., ATL Hawks)

gamelog = teamgamelog.TeamGameLog(team_id=team_id, season='2024-25', season_type_all_star='Regular Season')
team_logs = gamelog.get_data_frames()[0]

print(f"=== Game Log for {team_list[0]['full_name']} ===")
print(team_logs[['GAME_DATE', 'MATCHUP', 'WL', 'PTS', 'REB', 'AST']])
print()

# ========== PART 3: Play-by-Play Data ========== #
example_game_id = games_header['GAME_ID'].iloc[0]  # Grabs the first game from that date

pbp = playbyplayv2.PlayByPlayV2(game_id=example_game_id)
pbp_data = pbp.get_data_frames()[0]

print(f"=== Play-by-Play for Game {example_game_id} ===")
print(pbp_data[['EVENTNUM', 'EVENTMSGTYPE', 'HOMEDESCRIPTION', 'VISITORDESCRIPTION', 'PCTIMESTRING']].head(10))

# ========== Append to CSV Files (Safely) ========== #
def append_to_csv(df, filename):
    write_header = not os.path.exists(filename)
    df.to_csv(filename, mode='a', header=write_header, index=False)

# Save to persistent files
append_to_csv(games_header, 'nba_start_times.csv')
append_to_csv(team_logs, 'nba_team_logs.csv')
append_to_csv(pbp_data, 'nba_play_by_play.csv')

print("\n✅ Data appended to:")
print("- nba_start_times.csv")
print("- nba_team_logs.csv")
print("- nba_play_by_play.csv")
