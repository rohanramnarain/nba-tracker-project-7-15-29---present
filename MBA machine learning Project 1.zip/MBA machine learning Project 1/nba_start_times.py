import csv
import re
import requests
from datetime import datetime
from PyPDF2 import PdfReader
from io import BytesIO

# === Team name to abbreviation map (with aliases) ===
team_abbr = {
    "Atlanta Hawks": "ATL", "Boston Celtics": "BOS", "Brooklyn Nets": "BKN", "Charlotte Hornets": "CHA",
    "Chicago Bulls": "CHI", "Cleveland Cavaliers": "CLE", "Dallas Mavericks": "DAL", "Denver Nuggets": "DEN",
    "Detroit Pistons": "DET", "Golden State Warriors": "GSW", "Houston Rockets": "HOU", "Indiana Pacers": "IND",
    "LA Clippers": "LAC", "Los Angeles Clippers": "LAC",
    "Los Angeles Lakers": "LAL", "Memphis Grizzlies": "MEM", "Miami Heat": "MIA",
    "Milwaukee Bucks": "MIL", "Minnesota Timberwolves": "MIN", "New Orleans Pelicans": "NOP", "New York Knicks": "NYK",
    "Oklahoma City Thunder": "OKC", "Orlando Magic": "ORL", "Philadelphia 76ers": "PHI", "Phoenix Suns": "PHX",
    "Portland Trail Blazers": "POR", "Sacramento Kings": "SAC", "San Antonio Spurs": "SAS", "Toronto Raptors": "TOR",
    "Utah Jazz": "UTA", "Washington Wizards": "WAS"
}

# === PDF URL Generator ===
def build_pdf_url(game_date, away, home):
    try:
        date_obj = datetime.strptime(game_date.strip(), "%a, %b %d, %Y")
    except ValueError:
        date_obj = datetime.strptime(game_date.strip(), "%a %b %d %Y")
    date_str = date_obj.strftime("%Y%m%d")
    return f"https://statsdmz.nba.com/pdfs/{date_str}/{date_str}_{away}{home}_book.pdf"

# === Extract Start of 1st Quarter from PDF (in-memory) ===
def extract_first_quarter_start(pdf_url):
    try:
        response = requests.get(pdf_url, timeout=10)
        response.raise_for_status()

        reader = PdfReader(BytesIO(response.content))
        for page in reader.pages:
            text = page.extract_text()
            match = re.search(r"Start of 1st Quarter\s+(\d+:\d\d [AP]M)", text)
            if match:
                return match.group(1)
    except Exception as e:
        print(f"⚠️ Error reading PDF: {pdf_url}")
    return None

# === Main Script ===
input_csv = "nba_dates_of_games.csv"
output_csv = "nba_start_times.csv"
unknown_teams = set()

with open(input_csv, newline='', encoding='utf-8') as infile, open(output_csv, 'w', newline='', encoding='utf-8') as outfile:
    reader = csv.DictReader(infile)
    fieldnames = ['Date', 'Away Team', 'Home Team', 'PDF Link', 'Start of 1st Quarter']
    writer = csv.DictWriter(outfile, fieldnames=fieldnames)
    writer.writeheader()

    count = 0
    kept = 0
    for row in reader:
        count += 1
        game_date = row['Date']
        away_team = row['Away Team'].strip()
        home_team = row['Home Team'].strip()

        away_abbr = team_abbr.get(away_team)
        home_abbr = team_abbr.get(home_team)

        if not away_abbr or not home_abbr:
            unknown_teams.update([t for t in [away_team, home_team] if t not in team_abbr])
            continue

        pdf_url = build_pdf_url(game_date, away_abbr, home_abbr)
        start_time = extract_first_quarter_start(pdf_url)

        if start_time:
            writer.writerow({
                'Date': game_date,
                'Away Team': away_team,
                'Home Team': home_team,
                'PDF Link': pdf_url,
                'Start of 1st Quarter': start_time
            })
            kept += 1
        else:
            print(f"⏭️ Skipping: No start time in PDF for {away_team} @ {home_team} ({game_date})")

    print(f"\n✅ Finished processing {count} games.")
    print(f"📝 Successfully wrote {kept} games with valid start times.")

    if unknown_teams:
        print("⚠️ Unknown team names found:", ", ".join(sorted(unknown_teams)))
