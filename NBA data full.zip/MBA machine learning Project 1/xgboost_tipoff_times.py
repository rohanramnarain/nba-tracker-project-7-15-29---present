import pandas as pd
import joblib
import pathlib
import numpy as np
from datetime import datetime

# Load the trained model and preprocessor
print("Loading trained model...")
preprocessor = joblib.load(pathlib.Path("artifacts/preprocessor.joblib"))
model = joblib.load(pathlib.Path("artifacts/xgb_start_time.model"))

# Example: Predict for upcoming games
# You can either create a DataFrame manually or load from a CSV

# Option 1: Manual prediction for a single game
def predict_single_game(date_str, away_team, home_team, arena):
    """
    Predict tipoff time for a single game
    
    Args:
        date_str: Date in format like "Tue Oct 22 2024" or "2024-10-22"
        away_team: Away team name (should match training data)
        home_team: Home team name (should match training data)
        arena: Arena name (should match training data)
    """
    
    # Create a single-row DataFrame
    game_data = pd.DataFrame({
        'Arena': [arena],
        'Away Team': [away_team],
        'Home Team': [home_team]
    })
    
    # Parse the date and create time features
    try:
        date_obj = pd.to_datetime(date_str, format='mixed')
    except:
        # Try common date formats
        for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%a %b %d %Y']:
            try:
                date_obj = pd.to_datetime(date_str, format=fmt)
                break
            except:
                continue
        else:
            raise ValueError(f"Could not parse date: {date_str}")
    
    game_data['month'] = date_obj.month
    game_data['day_of_week'] = date_obj.dayofweek
    game_data['day_of_year'] = date_obj.dayofyear
    
    # Make prediction
    prediction_min = model.predict(preprocessor.transform(game_data))[0]
    
    # Convert minutes back to time format
    hours = int(prediction_min // 60)
    minutes = int(prediction_min % 60)
    
    # Convert to 12-hour format
    if hours == 0:
        time_str = f"12:{minutes:02d} AM"
    elif hours < 12:
        time_str = f"{hours}:{minutes:02d} AM"
    elif hours == 12:
        time_str = f"12:{minutes:02d} PM"
    else:
        time_str = f"{hours-12}:{minutes:02d} PM"
    
    return prediction_min, time_str

# Option 2: Load and predict for multiple games from CSV
def predict_from_csv(csv_file):
    """
    Load games from CSV and predict tipoff times
    CSV should have columns: Date, Away Team, Home Team, Arena
    """
    
    print(f"Loading games from {csv_file}...")
    games = pd.read_csv(csv_file)
    
    # Parse dates and create time features
    games['Date'] = pd.to_datetime(games['Date'], format='mixed', errors='coerce')
    games = games.dropna(subset=['Date']).copy()
    
    games['month'] = games['Date'].dt.month
    games['day_of_week'] = games['Date'].dt.dayofweek
    games['day_of_year'] = games['Date'].dt.dayofyear
    
    # Select features for prediction
    feature_columns = ['Arena', 'Away Team', 'Home Team', 'month', 'day_of_week', 'day_of_year']
    X_pred = games[feature_columns]
    
    # Make predictions
    predictions_min = model.predict(preprocessor.transform(X_pred))
    
    # Convert predictions to time format
    def min_to_time(minutes):
        hours = int(minutes // 60)
        mins = int(minutes % 60)
        if hours == 0:
            return f"12:{mins:02d} AM"
        elif hours < 12:
            return f"{hours}:{mins:02d} AM"
        elif hours == 12:
            return f"12:{mins:02d} PM"
        else:
            return f"{hours-12}:{mins:02d} PM"
    
    games['Predicted_Start_Time'] = [min_to_time(pred) for pred in predictions_min]
    games['Predicted_Start_Minutes'] = predictions_min
    
    # Save results
    output_file = "your_games.csv"
    games[['Date', 'Away Team', 'Home Team', 'Arena', 'Predicted_Start_Time', 'Predicted_Start_Minutes']].to_csv(
        output_file, index=False
    )
    
    print(f"✅ Predictions saved to {output_file}")
    return games

# Example usage:
if __name__ == "__main__":
    print("NBA Tipoff Time Predictor")
    print("=" * 40)
    
    # Example 1: Single game prediction
    print("\n1. Single Game Prediction Example:")
    try:
        pred_min, pred_time = predict_single_game(
            date_str="2025-11-15",  # Future date
            away_team="Los Angeles Lakers",  # Make sure this matches your training data
            home_team="Boston Celtics",      # Make sure this matches your training data
            arena="TD Garden"                # Make sure this matches your training data
        )
        print(f"Predicted tipoff time: {pred_time} ({pred_min:.1f} minutes)")
    except Exception as e:
        print(f"Error in single prediction: {e}")
        print("Make sure team names and arena match exactly with your training data")
    
    # Example 2: Batch prediction from CSV
    print("\n2. Batch Prediction from CSV:")
    print("To predict multiple games, create a CSV file with columns:")
    print("Date, Away Team, Home Team, Arena")
    print("Then call: predict_from_csv('your_games.csv')")
    
    # Show available teams and arenas from training data (if you want to check)
    print("\n3. Available teams and arenas in training data:")
    print("(Create a small CSV with games using these exact names)")
    
    # You can uncomment these lines to see what teams/arenas are available:
    # training_data = pd.read_csv("Actual_nba_start_times.csv")
    # print("Available arenas:", sorted(training_data['Arena'].unique()))
    # print("Available teams:", sorted(set(training_data['Away Team'].unique()) | set(training_data['Home Team'].unique())))